<?php
$servername = "localhost";
$username = "zeko";
$password = "hellozeko";
$dbname = "oe";
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>