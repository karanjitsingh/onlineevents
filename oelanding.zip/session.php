<?php
	include 'dbcon.php';
	global $conn;
	function checkSession($username , $token)
	{
		global $conn;
		$token = md5($token);
		session_start();
		if($_SESSION['username'] == $username && $_SESSION['session'])
		{
			$qry = "SELECT * FROM players_main WHERE user_username = '$username' AND user_token = '$token'";
			$result = mysqli_query($conn,$qry);
			if($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
?>