<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "karan";
$dbname = "oe_crossworld";
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
?>