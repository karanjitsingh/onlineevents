<?php
	include("login.php");
	clearSession();
?>