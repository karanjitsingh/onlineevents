<?php
session_start();
require_once("dbquestions.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Mechatron - Techtatva</title>
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="style.css">

	<script type="text/javascript" src="jquery.js"></script>
	<script>
	$(document).ready(function(){
	var src=$(".image").attr('src');
		
		if(src=='uploads/')
		{
			$(".image").hide();
		}
		$("#skip").click(function() {

	var hash="<?php echo $_SESSION['token']; ?>";
		$.ajax({
        url: 'skip.php',
        type: 'post',
		beforeSend:function() {
			alert('Please wait while we skip the question....');
		},
		cache:'false',
		async:false,
		dataType:'json',
        success: function(data) {
        	if(data.status=="1")
{
		location.reload(true);
	}
	else
	{
		alert("You have used your 3 skips.");
	}
		},
		error:function(data) {
			alert('error');
		},
		});
});
});
function allowDrop(ev) {
    ev.preventDefault();
}
function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}
function drop(ev,id) {
	var token="<?php echo $_SESSION['token']; ?>";
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
	var element=document.getElementById(data);
	var option=element.textContent;

	element.style.margin="0px";
	element.textContent="";
    ev.target.appendChild(document.getElementById(data));

    $.ajax({
        url: 'getanswer.php',
        type: 'get',
		cache:'false',
		dataType:'json',
		data:'option='+option+'&id='+id,
        success: function(data) {
        	if(data.status=="1")
        	{

        	
		ev.target.style.background=data.color;
	    element.style.display="none";
		$('#'+id).prop("ondrop",null);
		
	}
	if(data.status=="reload")
	{
		location.reload(true);
	}
		},
		error: function(e) {
			alert("error");
			location.reload(true);
  }
});

$.ajax({
        url: 'changestate.php',
        type: 'get',
		cache:'false',
		
		dataType:'json',
		
	
        success: function(data) {
        	if(data.status=="complete")
        	{
        		alert("You've completed the game successfully. Please wait for your score");
        	}
        
        if(data.status=="10")
        {
        alert("You placed a wrong option and a correct option in a row. You're being redirected to the next question.");
		$.ajax({
        url: 'action.php',
        type: 'post',
		cache:'false',
		dataType:'json',
        success: function(data) {
        	$(".score").text(data.score);
		location.reload(true);
		},
		});
        }
		if(data.status=="111")
		{
			$(".score").text(data.score);
		var id=data.id;
		var id1=data.id1;
		var id2=data.id2;
		$('#'+id).css('background-color','blue');
		$('#'+id1).css('background-color','inherit');
		$('#'+id2).css('background-color','inherit');
		
		$.ajax({
        url: 'action.php',
        type: 'post',
		cache:'false',
		
		dataType:'json',
		
        success: function(data) {

        	if(data.redirect=="1")
        	{
		location.reload(true);
	}
		},
		});
		}
		if(data.status=="000")
		{
			$(".score").text(data.score);
		var id=data.id;
		var id1=data.id1;
		var id2=data.id2;
		$('#'+id).css('background-color','#795548');
		$('#'+id1).css('background-color','inherit');
		$('#'+id2).css('background-color','inherit');
		
		$.ajax({
        url: 'action.php',
        type: 'post',
		cache:'false',
		
		dataType:'json',
		
        success: function(data) {
		location.reload();
		},
		});
		}
		if(data.status=="222")
		{
			$(".score").text(data.score);
		var id=data.id;
		var id1=data.id1;
		var id2=data.id2;
		var id3=data.id3;
		var id4=data.id4;
		$('#'+id).css('background-color','orange');
		$('#'+id1).css('background-color','inherit');
		$('#'+id2).css('background-color','inherit');
		$('#'+id3).css('background-color','inherit');
		$('#'+id4).css('background-color','inherit');
		
		}
		if(data.status=="333")
		{
			$(".score").text(data.score);
		var id=data.id;
		var id1=data.id1;
		var id2=data.id2;
		$('#'+id).css('background-color','purple');
		$('#'+id1).css('background-color','inherit');
		$('#'+id2).css('background-color','inherit');
		$('#'+id3).css('background-color','inherit');
		$('#'+id4).css('background-color','inherit');
		
		}

		},	

});
$.ajax({
        url: 'action.php',
        type: 'post',
		cache:'false',
		
		dataType:'json',
		
        success: function(data) {
        	if(data.redirect=="1")
        	{
		location.reload(true);
	}
		},
		});
}
 
</script>
</head>
<body>
	<div id="header">
		<img src="logo.png"><span><h2>TechTatva 15 | MECHATRON</h2>	</span>
		<ul class="header-right">
		<li>Hi <?php echo $_SESSION['username']; ?></li>
		<li><a target="_blank" href="https://drive.google.com/file/d/0B3oJu3kTkvh8V0EyN1FFdEMzOGc/view?usp=sharing">Rules</a></li>
		<li>Logout</li>
		</ul>
	</div >
	<br>
	<div id="content">
		<div id="content_left">
			<h1><?php echo $question; ?></h1>
			<ul>
				<?php 
	for($i=0;$i<count($options);$i++)
	{
		$z=$i+1;
	echo("<div id='draggable$z'  draggable='true' ondragstart='drag(event)' data-toggle='tooltip' title='Drag answers into the box'><a class='options' id='o$z'>$options[$i]</a></div>");
    }
    ?>
			</ul>
			<div id="image">
			<img height="300" width="600" src="<?php echo $image; ?>"></div>
		</div>

		<div id="content_right">
		<ul class="score-skip">
			<div class="other">
<li style="float:left;margin-right:40px;">Score:<?php echo $score; ?></li>
<li style="float:right;"><button id="skip">Skip</button></li>
</div></ul>
			 <?php include_once("table.php"); ?>

		</div>

	</div>
	<div id="bg_wrapper" align="center">
	<div id="img_wrapper"  align="center">
		<img src="bg/arrow1.jpg" id="img">
	</div>
	</div>

	<div class="vig"></div>

<script type="text/javascript">

    $(document).ready(function() {
        var height = Math.max($("#content_left").height(), $("#content_right").height());
        $("#content_left").height(height);
        $("#content_right").height(height);
    });

	var img=document.getElementById("img");
	$("#img").fadeTo("slow",1);
	var base="bg/";
	var imglist=["arrow1.jpg","gear.jpg","abstract.jpg"];

	//setTimeout(slideshow(), 2000);
	var counter=1;  //skip first element, it's already loaded
	var downloadingImage = new Image();
	downloadingImage.onload = function(){slideshow()};
	downloadingImage.src = base+imglist[1];

	function slideshow()
	{
		downloadingImage.onload = function(){;};   //reset onload handler, otherwise slideshow() everytime
		setInterval(function()
		{ 
			$("#bg_wrapper").fadeTo("",0);
			setTimeout( function(){img.src=downloadingImage.src},400); /*{img.src=base+imglist[counter++]+".jpg";}, 400);*/		
			$("#bg_wrapper").fadeTo("slow",1);
			if(counter==imglist.length)
				counter=0;
			downloadingImage.src = base+imglist[counter++];
		}, 5000);
	}
</script>
</body>
</html>