<?php
 session_start();
if(!isset($_SESSION['username']))
{
	die();
}
require_once("dbconnection.php"); 
$username=$_SESSION['username'];
 $sql="select * from oe_mechatron_users where Username='$username'";
 $result=mysqli_query($con,$sql);
 $row=mysqli_fetch_array($result,MYSQL_ASSOC);
 $qno=$row['QNo'];
 $skip=$row['Skip'];
 if($skip>0)
 {
 $skip--;
 $q=randomize();
 $sql1="update oe_mechatron_users set QNo='$q', Skip='$skip', Answered='0' where Username='$username'";
 $result1=mysqli_query($con,$sql1);
 $sql="insert into oe_mechatron_user_log(Username,QNo) values('$username','$q')";
 $result=mysqli_query($con,$sql);
 unset($_SESSION['options']);
 $data=array("status"=>"1");
 echo json_encode($data);
}
else
{
	$data=array("status"=>"0");
 echo json_encode($data);
}
function randomize()
{
$send=0;
	while($send==0)
	{
	$qno=rand(1,146);
	$sql="select * from oe_mechatron_user_log where Username='$username' and QNo='$qno'";
	$result=mysqli_query($con,$sql);
	$count=mysqli_num_rows($result);
	if($count==0)
	{
		$send=$qno;
		
	}
	}
	return $send;
}

?>


