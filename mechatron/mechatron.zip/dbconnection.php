<?php
$con=mysqli_connect("localhost","zeko","hellozeko","oe");
?>