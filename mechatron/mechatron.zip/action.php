<?php
session_start();
if(!isset($_SESSION['username']))
{
die();
}
 require_once("dbconnection.php");
 $username=$_SESSION['username'];
 $sql="select * from oe_mechatron_users where Username='$username'";
 $result=mysqli_query($con,$sql);
 $row=mysqli_fetch_array($result);
 $qno=$row['QNo'];
 $answered=$row['Answered'];
 if($answered==3)
 {
 $q=randomize();
 $sql1="update oe_mechatron_users set QNo='$q', Answered='0' where Username='$username'";
 $result1=mysqli_query($con,$sql1);
 $sql="insert into oe_mechatron_user_log(Username,QNo) values('$username','$q')";
 $result=mysqli_query($con,$sql);
 unset($_SESSION['options']);
 $data=array('redirect'=>'1');	
 }
 else
 {
 	$data=array("redirect"=>"0");
 }
echo json_encode($data);
function randomize()
{
	$send=0;
	do
	{
	$qno=rand(1,146);
	$sql="select * from oe_mechatron_user_log where Username='$username' and QNo='$qno'";
	$result=mysqli_query($con,$sql);
	$count=mysqli_num_rows($result);
	if($count==0)
	{
		$send=$qno;
	}
	}while($send==0);
	return $qno;
}
?>
